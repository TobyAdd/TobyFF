﻿Imports System.ComponentModel

Public Class setup

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim code As String = Me.code.Text
        Dim sb As New System.Text.StringBuilder

        sb.AppendLine(code)
        IO.File.WriteAllText("codedata.txt", sb.ToString())
        Me.Hide()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs)
        Me.code.Text = "chcp 65001"
    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs)

    End Sub

    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged
        Me.code.Text = "chcp 437"
    End Sub

    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton2.CheckedChanged
        Me.code.Text = "chcp 850"
    End Sub

    Private Sub RadioButton3_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton3.CheckedChanged
        Me.code.Text = "chcp 852"
    End Sub

    Private Sub RadioButton4_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton4.CheckedChanged
        Me.code.Text = "chcp 855"
    End Sub

    Private Sub RadioButton5_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton5.CheckedChanged
        Me.code.Text = "chcp 857"
    End Sub

    Private Sub RadioButton6_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton6.CheckedChanged
        Me.code.Text = "chcp 860"
    End Sub

    Private Sub RadioButton7_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton7.CheckedChanged
        Me.code.Text = "chcp 861"
    End Sub

    Private Sub RadioButton8_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton8.CheckedChanged
        Me.code.Text = "chcp 863"
    End Sub

    Private Sub RadioButton9_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton9.CheckedChanged
        Me.code.Text = "chcp 865"
    End Sub

    Private Sub RadioButton10_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton10.CheckedChanged
        Me.code.Text = "chcp 866"
    End Sub

    Private Sub RadioButton11_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton11.CheckedChanged
        Me.code.Text = "chcp 65001"
    End Sub

    Private Sub RadioButton12_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton12.CheckedChanged
        Me.code.Text = "chcp 1251"
    End Sub

    Private Sub Panel1_Paint_1(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub

    Private Sub RadioButton13_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton13.CheckedChanged
        Me.code.Text = "chcp 869"
    End Sub

    Private Sub RadioButton14_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton14.CheckedChanged
        Me.code.Text = "chcp 936"
    End Sub

    Private Sub setup_Closed(sender As Object, e As EventArgs) Handles Me.Closed
        MessageBox.Show("All changes was canceled", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Sub setup_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        code.Text = System.IO.File.ReadAllText("codedata.txt")
    End Sub
End Class